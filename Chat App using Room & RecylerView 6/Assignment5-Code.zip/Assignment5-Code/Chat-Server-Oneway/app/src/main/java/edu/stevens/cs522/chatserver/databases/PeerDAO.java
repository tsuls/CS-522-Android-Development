package edu.stevens.cs522.chatserver.databases;

import androidx.lifecycle.LiveData;
import androidx.room.Transaction;

import java.util.List;

import edu.stevens.cs522.chatserver.entities.Peer;

/*
 * TODO add annotations (NB insert should ignore conflicts, for upsert)
 *
 * We will continue to allow insertion to be done on main thread for noew.
 */
public abstract class PeerDAO {

    // TODO
    public abstract LiveData<List<Peer>> fetchAllPeers();

    /**
     * Add a peer record if it does not already exist;
     * update information if it is already defined.
     * https://stackoverflow.com/a/50736568
     */

    // TODO get peer record based on name
    protected abstract long getPeerId(String name);

    // TODO insert, ignore conflicts
    protected abstract long insert(Peer peer);

    // TODO update
    protected abstract void update(Peer peer);

    @Transaction
    /**
     * This operation must be transactional, to avoid race condition
     * between conflict on insert and update.
     */
    public long upsert(Peer peer) {
        // TODO
        return -1;
    }
}
