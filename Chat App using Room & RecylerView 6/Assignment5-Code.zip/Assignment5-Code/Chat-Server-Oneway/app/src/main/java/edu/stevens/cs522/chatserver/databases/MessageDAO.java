package edu.stevens.cs522.chatserver.databases;

import androidx.lifecycle.LiveData;

import java.util.List;

import edu.stevens.cs522.chatserver.entities.Message;

// TODO add annotations for Repository pattern
public interface MessageDAO {

    // TODO
    public LiveData<List<Message>> fetchAllMessages();

    // TODO
    public LiveData<List<Message>> fetchMessagesFromPeer(long peerId);

    // TODO
    public void persist(Message message);

}
